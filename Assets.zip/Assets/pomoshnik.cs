using UnityEngine;
using TMPro;

public class AIHelper : MonoBehaviour
{
    // Ссылка на игрока
    public Transform player;

    // Ссылка на компонент TextMeshPro
    private TextMeshPro textMesh;

    // Скорость движения помощника
    public float moveSpeed = 3f;

    // Расстояние, на котором помощник покажет сообщение
    public float messageDistance = 2f;

    // Флаг для отслеживания того, показывалось ли уже сообщение
    private bool messageShown = false;

    // Вызывается при старте
    void Start()
    {
        // Создаем компонент TextMeshPro
        textMesh = gameObject.AddComponent<TextMeshPro>();

        // Настройка параметров текста
        textMesh.fontSize = 1;
        textMesh.color = Color.white;
        textMesh.alignment = TextAlignmentOptions.Center;
        textMesh.text = "";
    }

    // Вызывается на каждом кадре
    void Update()
    {
        // Получаем направление к игроку
        Vector3 direction = (player.position - transform.position).normalized;

        // Перемещаем помощника в направлении игрока с заданной скоростью
        transform.position += direction * moveSpeed * Time.deltaTime;

        // Проверяем расстояние между помощником и игроком
        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        // Если помощник достиг игрока и сообщение ещё не показывалось, показываем сообщение
        if (distanceToPlayer < messageDistance && !messageShown)
        {
            textMesh.text = "Привет! Я здесь, чтобы помочь тебе!";
            messageShown = true;
        }
        else if (distanceToPlayer >= messageDistance && messageShown)
        {
            // Скрываем сообщение, когда расстояние больше, чем заданное
            textMesh.text = "";
            messageShown = false;
        }
    }
}