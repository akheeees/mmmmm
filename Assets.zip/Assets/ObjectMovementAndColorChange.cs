using UnityEngine;

public class ObjectMovementAndColorChange : MonoBehaviour
{
    public AnimationCurve movementCurve;
    public AnimationCurve colorCurve;

    public float moveSpeed = 2f;
    public Color startColor = Color.white;
    public Color endColor = Color.red;
    public float colorChangeDuration = 2f;

    private Vector3 initialPosition;
    private Renderer objectRenderer;
    private float elapsedTime = 0f;
    private bool isMoving = true; // Переключатель режима (true - перемещение, false - свечение)

    private void Start()
    {
        initialPosition = transform.position;
        objectRenderer = GetComponent<Renderer>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            isMoving = !isMoving; // Переключаем режим
            elapsedTime = 0f; // Сбрасываем время
        }

        if (isMoving)
        {
            // Режим перемещения
            MoveObject();
        }
        else
        {
            // Режим свечения
            ChangeColorOverTime();
        }
    }

    private void MoveObject()
    {
        float eval = movementCurve.Evaluate(elapsedTime);
        transform.position = initialPosition + Vector3.right * eval * moveSpeed;
        elapsedTime += Time.deltaTime;
    }

    private void ChangeColorOverTime()
    {
        float eval = colorCurve.Evaluate(elapsedTime / colorChangeDuration);
        objectRenderer.material.color = Color.Lerp(startColor, endColor, eval);
        elapsedTime += Time.deltaTime;
    }
}