using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 5f; // Скорость движения объекта 
    public float jumpForce = 10f; // Сила прыжка 
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Получаем ввод от клавиатуры для горизонтального и вертикального движения 
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        // Вычисляем направление движения 
        Vector3 movement = new Vector3(horizontalInput, 0f, verticalInput) * speed * Time.deltaTime;

        // Применяем движение к объекту 
        transform.Translate(movement);

        // Проверяем, нажата ли клавиша прыжка (стрелка вверх), и если да, прыгаем 
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            Jump();
        }
    }

    void Jump()
    {
        // Проверяем, находится ли объект на земле (можно изменить условие в зависимости от вашего проекта) 
        if (Mathf.Abs(rb.velocity.y) < 0.001f)
        {
            // Применяем силу прыжка к Rigidbody 
            rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }
    }
}