using UnityEngine;

public class EndGameOnTouch : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Проверяем, касается ли объект игрока
        if (collision.gameObject.CompareTag("Player"))
        {
            // Выходим из игры
            Application.Quit();
        }
    }
}
