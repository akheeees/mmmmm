using UnityEngine;

public class BladesRotation : MonoBehaviour
{
    // Скорость вращения лопастей
    public float rotationSpeed = 100f;

    // Update вызывается каждый кадр
    void Update()
    {
        // Вращение лопастей по оси Z по часовой стрелке
        transform.Rotate(Vector3.forward, -rotationSpeed * Time.deltaTime);
    }
}