using UnityEngine;

public class CharacterController : MonoBehaviour
{
    // Скорость передвижения персонажа
    public float moveSpeed = 5f;

    // Сила прыжка персонажа
    public float jumpForce = 10f;

    // Проверяем, находится ли персонаж на земле
    private bool isGrounded;

    // Радиус сферы для проверки наличия земли под персонажем
    public float groundCheckRadius = 0.2f;

    // Ссылка на компонент Rigidbody2D персонажа
    private Rigidbody2D rb;

    // Ссылка на компонент Animator персонажа
    private Animator animator;

    // Ссылка на Transform, который используется для проверки наличия земли под персонажем
    public Transform groundCheck;

    // Слой, представляющий землю
    public LayerMask whatIsGround;

    // Вызывается при старте
    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    // Вызывается на каждом кадре
    private void Update()
    {
        // Проверяем, находится ли персонаж на земле
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, whatIsGround);

        // Получаем ввод от игрока
        float moveInput = Input.GetAxisRaw("Horizontal");

        // Перемещаем персонажа по горизонтали
        rb.velocity = new Vector2(moveInput * moveSpeed, rb.velocity.y);

        // Изменяем анимацию персонажа
        animator.SetFloat("Speed", Mathf.Abs(moveInput));

        // Прыгаем, если нажата клавиша прыжка и персонаж стоит на земле
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }
    }
}