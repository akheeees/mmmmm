using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class raycastAibs : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 3.0f;
    [SerializeField] private bool isRight = true;
    [SerializeField] private float raycastDistance = 1f;
    [SerializeField] private SpriteRenderer spriteRenderer;

    [Header("Raycast Settings")]
    [Range(0.01f, 1f)]
    [SerializeField] private float raycastCheckInterval = 0.1f;

    void Start()
    {
        if (spriteRenderer == null)
            spriteRenderer = GetComponent<SpriteRenderer>();

        spriteRenderer.flipX = isRight;
    }

    void Update()
    {
        MoveObject();
    }

    private void MoveObject()
    {
        Vector3 directionTranslation = (isRight) ? transform.right : -transform.right;
        directionTranslation *= Time.deltaTime * moveSpeed;
        transform.Translate(directionTranslation);
        CheckForWalls();
    }

    private void CheckForWalls()
    {
        StartCoroutine(RaycastRoutine());
    }

    private IEnumerator RaycastRoutine()
    {
        while (true)
        {
            Vector3 raycastDirection = (isRight) ? Vector3.right : Vector3.left;
            RaycastHit2D hit = Physics2D.Raycast(transform.position + raycastDirection * raycastDistance - new Vector3(0f, 0.25f, 0f), raycastDirection, 0.075f);
            if (hit.collider != null)
            {
                if (hit.transform.CompareTag("Boxes"))
                {
                    isRight = !isRight;
                    spriteRenderer.flipX = isRight;
                }
            }

            yield return new WaitForSeconds(raycastCheckInterval);
        }
    }
}
